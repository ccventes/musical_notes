* Some unit tests.
* Update README documentation
* Provide API documentation, either by updating comments in fluidsynth.py or something else
* maybe get rid of this file and use github projects